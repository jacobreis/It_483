﻿using System;

public class Lab02
{
    public static void Main()
    {
        string glasses;
        double total = 0;
        string option;

        Console.WriteLine("What kind of glasses would you like:");

        while (true)
        {
            Console.Write("1 -> prescription, 2 -> non-prescripton : ");

            glasses = Console.ReadLine();

            if (glasses == "1")
            {
                total += 40;
                break;
            }
            else if (glasses == "2")
            {
                total += 25;
                break;
            }
            else
            {
                continue;
            }
        }

        while (true)
        {
            Console.WriteLine("What kind of coating would you like:");
            Console.Write("1 -> anti-glare, 2 -> brown tint : ");

            option = Console.ReadLine();

            if (glasses == "1")
            {
                total += 12.50;
                break;
            }
            else if (glasses == "2")
            {
                total += 9.99;
                break;
            }
            else
            {
                continue;
            }
        }

        Console.WriteLine("Your total cost is $" + total);
    }
}
