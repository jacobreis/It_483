"use strict"

var $ = function (id) {
    return document.getElementById(id);
}

var calculateSalesTax = function (subtotal, tax_rate) {
    var sales_tax = ((tax_rate / 100) * subtotal);
    return sales_tax;
}
var calculateTotal = function (subtotal, sales_tax) {
    var tax_rate = (subtotal + sales_tax);
    return tax_rate;
}
var processEntries = function () {
    var subTotal = parseFloat($("subtotal").value);
    var tax_Rate = parseFloat($("tax_rate").value);
    if (isNaN(subTotal) || isNaN(tax_Rate)) {
        alert("Both entries must be numeric");
    } else if (subTotal < 0 || subTotal >= 10000 || tax_Rate < 0 || tax_Rate >= 12) {
        alert("Subtotal must be > 0 and < 10000 \nTax Rate must be > 0 and < 12 ");
    } else {
        var salesTax = calculateSalesTax(subTotal, tax_Rate);
        var total = calculateTotal(subTotal, salesTax);
        $("sales_tax").value = salesTax;
        $("total").value = total;
    }
}

var clearSubtotal = function () {
    $("subtotal").value = "";
}

var clearTaxRate = function () {
    $("tax_rate").value = "";
}

var clearAll = function(){
    $("subtotal").value = "";
    $("tax_rate").value = "";
    $("sales_tax").value = "";
    $("total").value = "";
    $("subtotal").focus();
}

var focusSubtotal = function(){
    $("subtotal").focus();
}

var multiFunction = function(){
    processEntries();
    focusSubtotal();
}


window.onload = function () {
    $("calculate").onclick = multiFunction;
    $("clear").onclick = clearAll;
    $("subtotal").focus();
    $("subtotal").onfocus = clearSubtotal;
    $("tax_rate").onfocus = clearTaxRate;

}
