﻿using System;

namespace Lab04
{
    class Program
    { 
        public static double Average(int a, int b)
        {
            return (a + b) / 2.0;
        }

        public static double Average(int a, int b, int c)
        {
            return (a + b + c) / 3.0;
        }

        public static double Average(double a, double b)
        {
            return (a + b) / 2.0;
        }

        public static double Average(double a, double b, double c)
        {
            return (a + b + c) / 3.0;
        }

        static void Main(string[] args)
        {
            int a = 1;
            int b = 3;
            int c = 5;

            double x = 2.2;
            double y = 4.4;
            double z = 6.6;
            double ans;

            ans = Average(a, b);
            Console.WriteLine("\nAverage(a,b) = " + ans);

            ans = Average(a, b, c);
            Console.WriteLine("\nAverage(a,b,c) = " + ans);

            ans = Average(x, y);
            Console.WriteLine("\nAverage(x,y) = " + ans);

            ans = Average(x, y, z);
            Console.WriteLine("\nAverage(x,y,z) = " + ans);

            ans = Average(Average(a, b), c);
            Console.WriteLine("\nAverage(Average(a,b),c) = " + ans);

            ans = Average(a, x, b);
            Console.WriteLine("\nAverage(x,y,z) = " + ans);
            
            //1. Does not seem to be necessary due to variable casting from integer into a double being possible 
            //2. Yes, it is needed. The average of another average will provide a different answer.
            //3. It is legal do to casting. The 4th method is used. 

        }
    }
}
