﻿using System;

namespace Lab03
{
    class Bank
    {
        public static double Transaction(double balance = 0, double amount = 0)
        {
            if (amount >= 0)
            {
                return amount;
            }
            else
            {
                if ((balance + amount) < 0)
                {
                    amount = amount + ((amount * (-1)) - balance);
                    balance = 0;
                    return amount;
                }
                else
                {
                    return amount;
                }
            }
        }

        static void Main(string[] args)
        {
            double balance = 0.0;

            while (true){

                Console.Write("Please enter an amount to update account by: $");
                double amount = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("");

                Console.WriteLine("Customer's balance (Before transaction) = $" + balance);
                Console.WriteLine("Requested update amount = $" + amount);

                double actAmount = Transaction(balance, amount);

                balance += actAmount;

                Console.WriteLine("Actual update amount = $" + actAmount);
                Console.WriteLine("Customer's balance (After transaction) = $" + balance);

                Console.Write("\nWould you like to continue? (y/n): ");
                string i = Console.ReadLine();

                if (i == "n" || i == "N")
                {
                    Console.WriteLine("\nThank you and good-bye!\n");
                    break;
                }
            }


        }
    }
}